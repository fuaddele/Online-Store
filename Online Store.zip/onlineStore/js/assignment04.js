function add_user() {
    var title = $('#title').val();
    var first_name = $('#first_name').val();
    var sur_name = $('#sur_name').val();
    var mobile = $('#mobile').val();
    var email_address = $('#email_address').val();
    var address_line1 = $('#address_line1').val();
    var address_line2 = $('#address_line2').val();
    var town = $('#town').val();

    var county = $('#county').val();

    var Eircode = $('#Eircode').val();

    $.ajax({
        url: "assignment04_save.php",
        type: "POST",
        data: {

            title: title,
            first_name: first_name,
            sur_name: sur_name,
            mobile: mobile,
            email_address: email_address,
            address_line1: address_line1,
            address_line2: address_line2,
            town: town,
            county: county,
            Eircode: Eircode

        },
        success: function (data) {

            console.log("User added successfully!");
        },
        error: function () {
            // Handle error case
            console.log("Error adding user!");
        }
    });
}

function delete_user(id) {

    var confirmDelete = confirm("Are you sure you want to delete this user?");
    if (confirmDelete) {
        $.ajax({
            url: "assignment04_delete.php",
            type: "post",
            data: { id: id },
            success: function (data) {

                console.log("User deleted successfully!");
                location.reload();
            },
            error: function () {
                console.log("Error deleting user!");
            }
        });
    }
}

//edit user function 
function edit_user(id) {
    $('id').val(id);

    $.post("update_user.php", {
        id: id

    }, function (data, status) {

        var user = JSON.parse(data);
        $('#title').val(user.title);
        $('#first_name').val(user.first_name);
        $('#sur_name').val(user.sur_name);
        $('#email_address').val(user.email_address);
        $('#address_line1').val(user.address_line1);
        $('#address_line2').val(user.address_line2);
        $('#town').val(user.town);
        $('#county').val(user.county);
        $('#Eircode').val(user.Eircode);

    }

    );
    $('edit_user').show();


}