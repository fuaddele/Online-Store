SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `USERS`;
CREATE TABLE IF NOT EXISTS `USERS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sur_name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `town` varchar(255) NOT NULL,
  `county` varchar(255) NOT NULL,
  `Eircode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `USERS` (`id`, `title`, `first_name`, `sur_name`, `mobile`, `email_address`, `address_line1`, `address_line2`, `town`, `county`, `Eircode`) VALUES
(1, 'Mr', 'Fuad', 'Dele-Ganiyu', '0873405881', 'fuad.deleganiyu.2022@mumail.ie', '7 HAyworth Mews', 'Ongar Park', 'Dublin 15', 'Dublin', 'D15A2TW');
COMMIT;
