<?php
// Get the user data from the POST request
$title = $_POST['title'];
$first_name = $_POST['first_name'];
$sur_name = $_POST['sur_name'];
$mobile = $_POST['mobile'];
$email_address = $_POST['email_address'];
$address_line1 = $_POST['address_line1'];
$address_line2 = $_POST['address_line2'];
$town = $_POST['town'];
$county = $_POST['county'];
$eircode = $_POST['Eircode'];

// Insert the user data into the database
$conn = new mysqli('localhost', 'root', '', 'online_store');
$sql = "INSERT INTO USERS (title, first_name, sur_name, mobile, email_address, address_line1, address_line2, town, county, eircode)
        VALUES ('$title', '$first_name', '$sur_name', '$mobile', '$email_address', '$address_line1', '$address_line2', '$town', '$county', '$eircode')";
$result = $conn->query($sql);

if ($result) {
  echo "User data saved successfully!";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
