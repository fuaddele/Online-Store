<?php
$conn = new mysqli('localhost', 'root', '', 'online_store');

if(isset($_POST['submit'])) {

    // Check if the id key is set in the $_GET array
    if(isset($_GET['id'])) {
        $id = $_GET['id'];
    } else {
        // Handle the case where the id key is not set
        echo "Error: User ID not specified.";
        exit();
    }

    // Get the rest of the form data
    $title = $_POST['title'];
    $first_name = $_POST['first_name'];
    $sur_name = $_POST['sur_name'];
    $mobile = $_POST['mobile'];
    $email_address = $_POST['email_address'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = $_POST['address_line2'];
    $town = $_POST['town'];
    $county = $_POST['county'];
    $Eircode = $_POST['Eircode'];

    // Update the user data in the database
    $query = "UPDATE USERS SET title='$title', first_name='$first_name', sur_name='$sur_name', mobile='$mobile', email_address='$email_address', address_line1='$address_line1', address_line2='$address_line2', town='$town', county='$county', Eircode='$Eircode' WHERE id='$id'";

    if(mysqli_query($conn, $query)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error updating user: " . mysqli_error($conn);
    }
}


mysqli_close($conn);
?>
