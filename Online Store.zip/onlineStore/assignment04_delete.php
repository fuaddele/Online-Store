<?php
if(isset($_POST['id'])) {


  $id =$_POST['id'];
  $conn = new mysqli('localhost', 'root', '', 'online_store');

  $query = "DELETE FROM USERS WHERE id='$id'";
  $result = $conn->query($query);

  if ($result) {
    echo "User data deleted successfully!";
  } else {
    echo "Error deleting user: " . $conn->error;
  }
}
$conn->close();
?>