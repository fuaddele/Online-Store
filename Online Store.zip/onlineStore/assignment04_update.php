<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title> Admin Panel</title>
      <!-- Bootstrap -->
      <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet" />

   </head>
   <body class="hold-transition sidebar-mini">
   <!--preloader-->
      <div id="preloader">
         <div id="status"></div>
      </div>
      <!-- Site wrapper -->
      <div class="wrapper">
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <div class="header-icon">
                  <i class="fa fa-users"></i>
               </div>
               <div class="header-title">
                  <h1>Update Users</h1>
               </div>
            </section>

            <?php
$conn = new mysqli('localhost', 'root', '', 'online_store');

$result = mysqli_query($conn,"SELECT * FROM USERS WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
?>
            <!-- Main content -->
            <div class="content">
            <form method="post" action="assignment04_edit.php?id=<?php echo $row['id']; ?>">
            <div class="row">

                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Title:</label>
                                          <input type="text" id="title" name="title" value="<?php echo $row['title']; ?>" placeholder="Enter Title" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">First Name</label>
                                          <input type="text" id="first_name" name="first_name" value="<?php echo $row['first_name']; ?>" placeholder="First Name" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Surname</label>
                                          <input type="text" name="sur_name" id="sur_name" value="<?php echo $row['sur_name']; ?>" placeholder="Surname" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Mobile</label>
                                          <input type="text" name="mobile" id="mobile" value="<?php echo $row['mobile']; ?>"  placeholder="Mobile" class="form-control">
                                       </div>
   <div class="col-md-6 form-group">
                                          <label class="control-label">Email Address</label>
                                          <input type="text" name="email_address" id="email_address" value="<?php echo $row['email_address']; ?>"  placeholder="Email Address" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Address 1</label>
                                          <input type="text" name="address_line1" id="address_line1" value="<?php echo $row['address_line1']; ?>"  placeholder="Address 1" class="form-control">
                                       </div>
                                         <div class="col-md-6 form-group">
                                          <label class="control-label">Address 2</label>
                                          <input type="text" name="address_line2" id="address_line2" value="<?php echo $row['address_line2']; ?>"  placeholder="Address 2" class="form-control">
                                       </div>
   <div class="col-md-6 form-group">
                                          <label class="control-label">Town</label>
                                          <input type="text" name="town" id="town" value="<?php echo $row['town']; ?>"  placeholder="Enter town" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">County</label>
                                          <input type="text" name="county" id="county"  value="<?php echo $row['county']; ?>"  placeholder="County" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Eircode</label>
                                           <input type="text" name="Eircode" id="Eircode" value="<?php echo $row['Eircode']; ?>"  placeholder="Eircode" class="form-control">
                                       </div>
                                      
                                    </div>
                                    <div>
                                       <button type="submit" class="btn btn-primary" name="submit">Update</button>
                                       </div>
                                    </form>
            </div>
            <!-- /.content -->
         </div>
         <!-- /.content-wrapper -->
        
      </div>
      <!-- jQuery -->
      <script src="./jQuery/jquery-1.12.4.min.js"></script>
      <!-- Bootstrap proper -->
      <script src="./bootstrap/js/popper.min.js"></script>
      <script src="./bootstrap/js/bootstrap.min.js"></script>
   </body>
</html>

