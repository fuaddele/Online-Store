<!-- Windows Version 11 -->
<!-- Chrome Version 111.0.5563.147 -->
<!-- XAMPP version 3.3.0 -->
<!-- Load server from this page -->


<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "online_store";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);

  
}
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title> User Page</title>
      <!-- Bootstrap -->
      <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   </head>
   <body class="hold-transition sidebar-mini">
   <!--preloader-->
      <div id="preloader">
         <div id="status"></div>
      </div>
      <!-- Site wrapper -->
      <div class="wrapper">
         <!-- =============================================== -->
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <div class="header-title">
               </div>
            </section>
            <!-- Main content -->
            <section class="content">
               <div class="row">
                     <div class="col-lg-12 pinpin">
                           <div class="card lobicard"  data-sortable="true">
                               <div class="card-header">
                                   <div class="card-title custom_title">
                                       <h4>Users</h4>
                                   </div>
                               </div>
                               <div class="card-body">
                                    <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                                       <div class="btn-group d-flex" role="group">
                                          <div class="buttonexport" id="buttonlist"> 
                                          <a data-toggle="modal" data-target="#add_user" class="btn btn-add" href="add-customer.html">
  <i class="fa fa-plus"></i>+ Add User
</a>

                                          </div>
                                       </div> 
                                     
                                       <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                                       <div class="table-responsive">
  <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
    <thead class="back_table_color">
      <tr class="info">
        <th>Title</th>
        <th>First Name</th>
        <th>Surname</th>
        <th>Mobile Num</th>
        <th>Email Address</th>
        <th>Address 1</th>
        <th>Address 2</th>
        <th>Town</th>
        <th>County</th>
        <th>Eir Code</th>
        <th>Update</th>
        <th>Delete</th>

      </tr>
    </thead>
    <tbody>
      <?php
        $query = "SELECT * FROM USERS";
        $result = $conn->query($query);
        if (!$result) {
          die('Error');
        }

        while ($row = $result->fetch_assoc()) {
          echo '<tr>';
          echo '<td>' . $row['title'] . '</td>';
          echo '<td>' . $row['first_name'] . '</td>';
          echo '<td>' . $row['sur_name'] . '</td>';
          echo '<td>' . $row['mobile'] . '</td>';
          echo '<td>' . $row['email_address'] . '</td>';
          echo '<td>' . $row['address_line1'] . '</td>';
          echo '<td>' . $row['address_line2'] . '</td>';
          echo '<td>' . $row['town'] . '</td>';
          echo '<td>' . $row['county'] . '</td>';
          echo '<td>' . $row['Eircode'] . '</td>';
          echo '<td><a href="assignment04_update.php?id=' . $row['id'] . '" class="btn btn-primary">Edit</a></td>';
          echo '<td><button onclick="delete_user('.$row['id'].')" class="btn btn-danger">Delete</button></td>';
          echo '</tr>';
        }
      ?>
    </tbody>
  </table>
</div>


               <div class="modal fade" id="add_user" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header modal-header-primary">
                           <h3><i class="fa fa-user m-r-5"></i>Add Users</h3>
                           <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <form  id="myForm"  method="post" class="form-horizontal">
                                    <div class="row">
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Title</label>
                                          <input type="text" id="title" name="title" placeholder="Enter Title" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">First Name</label>
                                          <input type="text" id="first_name" name="first_name" placeholder="First Name" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Surname</label>
                                          <input type="text" name="sur_name" id="sur_name" placeholder="Surname" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Mobile</label>
                                          <input type="text" name="mobile" id="mobile" placeholder="Mobile" class="form-control">
                                       </div>
   <div class="col-md-6 form-group">
                                          <label class="control-label">Email Address</label>
                                          <input type="text" name="email_address" id="email_address" placeholder="Email Address" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Address 1</label>
                                          <input type="text" name="address_line1" id="address_line1" placeholder="Address 1" class="form-control">
                                       </div>
                                         <div class="col-md-6 form-group">
                                          <label class="control-label">Address 2</label>
                                          <input type="text" name="address_line2" id="address_line2" placeholder="Address 2" class="form-control">
                                       </div>
   <div class="col-md-6 form-group">
                                          <label class="control-label">Town</label>
                                          <input type="text" name="town" id="town" placeholder="Enter town" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">County</label>
                                          <input type="text" name="county" id="county" placeholder="County" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Eircode</label>
                                           <input type="text" name="Eircode" id="Eircode" placeholder="Eircode" class="form-control">
                                       </div>
                                       <div class="col-md-12 form-group user-form-group">
                                          <div class="float-right">
                                             <button type="button" class="btn btn-danger btn-sm">Cancel</button>
                                             <button type="submit" class="btn btn-add btn-sm" onclick="add_user()">Save</button>
                                          </div>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-danger float-left" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div>


               <!-- //edit data -->


               <div class="modal fade" id="edit_user" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header modal-header-primary">
                           <h3><i class="fa fa-user m-r-5"></i>Edit Users</h3>
                           <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <form  id="myForm"  method="post" class="form-horizontal">
                                    <div class="row">
                                       <div class="col-md-6 form-group">
                                          <label for="title" class="control-label">Title</label>
                                          <input type="text" id="title" name="title" placeholder="Enter Title" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">First Name</label>
                                          <input type="text" id="first_name" name="first_name" placeholder="First Name" class="form-control">
                                       </div>
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Surname</label>
                                          <input type="text" name="sur_name" id="sur_name" placeholder="Surname" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Mobile</label>
                                          <input type="text" name="mobile" id="mobile" placeholder="Mobile" class="form-control">
                                       </div>
   <div class="col-md-6 form-group">
                                          <label class="control-label">Email Address</label>
                                          <input type="text" name="email_address" id="email_address" placeholder="Email Address" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Address 1</label>
                                          <input type="text" name="address_line1" id="address_line1" placeholder="Address 1" class="form-control">
                                       </div>
                                         <div class="col-md-6 form-group">
                                          <label class="control-label">Address 2</label>
                                          <input type="text" name="address_line2" id="address_line2" placeholder="Address 2" class="form-control">
                                       </div>
   <div class="col-md-6 form-group">
                                          <label class="control-label">Town</label>
                                          <input type="text" name="town" id="town" placeholder="Enter town" class="form-control">
                                       </div>
                                        <div class="col-md-6 form-group">
                                          <label class="control-label">Town</label>
                                          <input type="text" name="county" id="county" placeholder="County" class="form-control">
                                       </div>                  
                                       <div class="col-md-6 form-group">
                                          <label class="control-label">Eircode</label>
                                           <input type="text" name="Eircode" id="Eircode" placeholder="Eircode" class="form-control">
                                       </div>
                                       <div class="col-md-12 form-group user-form-group">
                                          <div class="float-right">
                                             <button type="button" class="btn btn-danger btn-sm">Cancel</button>
                                             <button type="submit" class="btn btn-add btn-sm" onclick="updateuser()">Save</button>
                                          </div>
                                       </div>
                                       <input type="hidden" id="id" name="id">

                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-danger float-left" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div>


               <div class="modal fade" id="customer2" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header modal-header-primary">
                           <h3><i class="fa fa-user m-r-5"></i> Delete Customer</h3>
                           <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <form class="form-horizontal">
                                       <div class="row">
                                             <div class="col-md-12 form-group user-form-group">
                                                <label class="control-label">Delete Customer</label>
                                                <div class="float-right">
                                                   <button type="button" class="btn btn-danger btn-sm">NO</button>
                                                   <button type="submit" class="btn btn-add btn-sm">YES</button>
                                                </div>
                                             </div>
                                       </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-danger float-left" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                     <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
               </div>
               <!-- /.modal -->
            </section>
            <!-- /.content -->
         </div>
         <!-- /.content-wrapper -->
       
      </div>
      <!-- index -->
      <script src="./js/assignment04.js"></script>
      <!-- jQuery -->
      <script src="./jQuery/jquery-1.12.4.min.js" ></script>
      <!-- Bootstrap -->
      <script src="./bootstrap/js/popper.min.js" ></script>
      <script src="./bootstrap/js/bootstrap.min.js" ></script>     
   </body>
</html>

